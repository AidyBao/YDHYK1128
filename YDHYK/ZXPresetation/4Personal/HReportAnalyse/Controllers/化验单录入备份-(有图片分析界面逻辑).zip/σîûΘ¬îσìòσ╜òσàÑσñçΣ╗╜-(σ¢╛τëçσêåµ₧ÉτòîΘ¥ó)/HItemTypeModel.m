//
//  HItemType.m
//  YDHYK
//
//  Created by screson on 2016/12/13.
//  Copyright © 2016年 screson. All rights reserved.
//

#import "HItemTypeModel.h"

@implementation HItemTypeModel

@end
