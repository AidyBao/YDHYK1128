//
//  HReportDetialViewController.h
//  ydhyk
//
//  Created by screson on 2016/11/22.
//  Copyright © 2016年 120v. All rights reserved.
//

#import <UIKit/UIKit.h>
/**分析记录详情页*/

@interface HReportDetialViewController : UIViewController

@property (nonatomic,copy) NSString * reportId;

@end
