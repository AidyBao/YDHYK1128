//
//  HNewReportRecordViewController.h
//  YDHYK
//
//  Created by screson on 2016/12/12.
//  Copyright © 2016年 screson. All rights reserved.
//

#import <UIKit/UIKit.h>


/**化验单录入界面*/
@interface HNewReportRecordViewController : UIViewController

@property (nonatomic,strong) UIImage  * imageReport;
//用来上传
@property (nonatomic,copy)   NSString * imageUrl;

@end
