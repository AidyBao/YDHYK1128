//
//  HAddCheckItemViewController.h
//  YDHYK
//
//  Created by screson on 2016/12/12.
//  Copyright © 2016年 screson. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZXCheckItemListModel.h"

typedef void(^ZXItemCheckEnd)(NSArray <ZXCheckItemListModel *> * list);
/**化验单 - 选择添加检查项目*/
@interface HAddCheckItemViewController : UIViewController

@property (nonatomic,copy) ZXItemCheckEnd checkEnd;

@end
