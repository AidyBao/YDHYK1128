//
//  HReportAnalyseRootViewController.h
//  ydhyk
//
//  Created by screson on 2016/11/21.
//  Copyright © 2016年 120v. All rights reserved.
//

#import <UIKit/UIKit.h>

/**化验单分析 ROOTVC*/
@interface HReportAnalyseRootViewController : UIViewController

@end
