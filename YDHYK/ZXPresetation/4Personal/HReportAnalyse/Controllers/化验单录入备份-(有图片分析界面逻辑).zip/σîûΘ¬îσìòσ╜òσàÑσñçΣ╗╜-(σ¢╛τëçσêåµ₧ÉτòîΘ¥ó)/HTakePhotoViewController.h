//
//  HTakePhotoViewController.h
//  ydhyk
//
//  Created by screson on 2016/11/22.
//  Copyright © 2016年 120v. All rights reserved.
//

#import <UIKit/UIKit.h>

/**化验单拍照录入*/
@interface HTakePhotoViewController : UIViewController

@end
