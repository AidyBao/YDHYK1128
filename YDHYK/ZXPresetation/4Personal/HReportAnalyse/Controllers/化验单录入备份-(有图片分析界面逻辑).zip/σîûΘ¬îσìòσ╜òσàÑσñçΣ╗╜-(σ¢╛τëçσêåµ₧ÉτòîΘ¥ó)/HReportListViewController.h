//
//  HReportListViewController.h
//  ydhyk
//
//  Created by screson on 2016/11/22.
//  Copyright © 2016年 120v. All rights reserved.
//

#import <UIKit/UIKit.h>

/**化验单分析 记录 列表界面*/
@interface HReportListViewController : UIViewController

@end
