//
//  HReportResultViewController.h
//  ydhyk
//
//  Created by JuanFelix on 2016/11/23.
//  Copyright © 2016年 120v. All rights reserved.
//

#import <UIKit/UIKit.h>

/**分析结果详情*/
@interface HReportResultViewController : UIViewController

@property (nonatomic,strong) NSString * reportId;
@property (nonatomic,assign) BOOL isAbnormal;
@property (nonatomic,assign) BOOL pushFromNewReportVC;

@end
