//
//  HReportModelViewController.h
//  YDHYK
//
//  Created by screson on 2016/12/12.
//  Copyright © 2016年 screson. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HAddCheckItemViewController.h"

/**化验单模板*/
@interface HReportModelViewController : UIViewController

@property (nonatomic,copy) ZXItemCheckEnd checkEnd;

@end
